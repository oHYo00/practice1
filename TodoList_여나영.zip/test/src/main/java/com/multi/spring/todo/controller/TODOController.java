package com.multi.spring.todo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.multi.spring.todo.model.dto.TODODTO;
import com.multi.spring.todo.service.TODOService;

@SessionAttributes("loginUser")
@Controller
@RequestMapping("/todo")
public class TODOController {

    private final TODOService todoService;

    @Autowired
    public TODOController(TODOService todoService) {
        this.todoService = todoService;
    }

    @RequestMapping("/main")
    public String main() {
        return "redirect:/index.jsp";
    }

    @RequestMapping("/todo")
    public void todoMain() {
    }

    @RequestMapping("/delete_form")
    public void deleteForm() {
    }

    @RequestMapping("/insert_form")
    public void insertForm() {
    }

    @RequestMapping("/one_form")
    public void oneForm() {
    }

    @RequestMapping("/update_form")
    public void updateForm() {
    }

    @PostMapping("/insert")
    public String insertTODO(TODODTO todoDTO, HttpSession session) throws Exception {
        System.out.println("insert  ==>  " + todoDTO);
        todoService.insertTodo(todoDTO);
        session.setAttribute("msg", "할 일 추가 성공");
        return "redirect:/todo/insert_form";
    }

    @GetMapping("/list")
    public void selectList(Model model) throws Exception {
        List<TODODTO> list = todoService.selectList();
        model.addAttribute("list", list);
    }


    @GetMapping("/delete")
    public String deleteTODO(String priority) throws Exception {
        todoService.deleteTodo(priority);
        return "redirect:/todo/delete_form";
    }

    @PostMapping("/update")
    public String updateTODO(TODODTO todoDTO, HttpSession session) throws Exception {
        System.out.println("update  ==>  " + todoDTO);
        todoService.updateTodo(todoDTO);
        session.setAttribute("msg", "할 일 수정 성공");
        return "redirect:/todo/update_form";
    }

    @GetMapping("/one")
    public void selectTODO(String priority, Model model) throws Exception {
        TODODTO dto = todoService.selectTodo(priority);
        model.addAttribute("dto", dto);
    }

}
