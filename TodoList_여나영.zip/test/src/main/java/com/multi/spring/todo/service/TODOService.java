package com.multi.spring.todo.service;

import java.util.List;
import com.multi.spring.todo.model.dto.TODODTO;

public interface TODOService {

    List<TODODTO> selectList() throws Exception;

    void deleteTodo(String priority) throws Exception;

    void updateTodo(TODODTO todoDTO) throws Exception;

    TODODTO selectTodo(String priority) throws Exception;

    void insertTodo(TODODTO todoDTO) throws Exception;

}
