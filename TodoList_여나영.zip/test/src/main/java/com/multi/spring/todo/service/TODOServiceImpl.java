package com.multi.spring.todo.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.multi.spring.todo.model.dao.TODODAO;
import com.multi.spring.todo.model.dto.TODODTO;

@Service
public class TODOServiceImpl implements TODOService {

    private final TODODAO todoDAO;
    
    @Autowired
    private SqlSessionTemplate sqlSession;

    @Autowired
    public TODOServiceImpl(TODODAO todoDAO) {
        this.todoDAO = todoDAO;
    }

	@Override
	public List<TODODTO> selectList() throws Exception {
		List<TODODTO> list = todoDAO.selectList(sqlSession);
		return list;
	}

	@Override
	public void deleteTodo(String priority) throws Exception {
	    int result = todoDAO.deleteTODO(sqlSession, priority);
	    if (result < 1) {
	        throw new Exception("할 일 삭제에 실패하였습니다.");
	    }
	}
	
    @Override
    public void updateTodo(TODODTO todoDTO) throws Exception {
        int result = todoDAO.updateTODO(sqlSession, todoDTO);
        if (result < 0) {
            throw new Exception("할 일 수정에 실패 하였습니다.");
        }
    }

	@Override
	public TODODTO selectTodo(String priority) throws Exception {
		TODODTO dto = todoDAO.selectTodo(sqlSession , priority);
		return dto;
			
	}

    @Override
    public void insertTodo(TODODTO todoDTO) throws Exception {
        // TODO: Implement insertion logic
    }

}
