package com.multi.spring.todo.model.dao;

import java.util.List;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;
import com.multi.spring.todo.model.dto.TODODTO;

@Repository
public class TODODAO {
    public int insertTODO(SqlSessionTemplate sqlSession, TODODTO todoDTO) {
        return sqlSession.insert("todoMapper.insertTodo", todoDTO);
    }
    
    public List<TODODTO> selectList(SqlSessionTemplate sqlSession){
        return sqlSession.selectList("todoMapper.selectList");
    }

    public int deleteTODO(SqlSessionTemplate sqlSession, String priority){
        return sqlSession.delete("todoMapper.deleteTodo", priority);
    }
    
    public TODODTO selectTodo(SqlSessionTemplate sqlSession, String priority) {
        int priorityInt = Integer.parseInt(priority);
        return sqlSession.selectOne("todoMapper.selectTodo", priorityInt);
    }

    public int updateTODO(SqlSessionTemplate sqlSession, TODODTO todoDTO){
        return sqlSession.update("todoMapper.updateTodo", todoDTO);
    }

}
